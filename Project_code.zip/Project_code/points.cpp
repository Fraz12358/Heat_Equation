#include <iostream>
#include <cmath>
#include <mpi.h>

using namespace std;

static const double PI = 3.1415926536; 

//Heart hole
int heart(int x, int y){
  if (2*pow((y-500),2) + pow((((7/4)*(x-500)) - 4*pow(abs(y-500),0.5)), 2) > pow(250,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Circle hole
int circle(int x, int y){
  if (pow((x-500),2) + pow((y-500),2) > pow(150,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Diamond hole
int diamond(int x, int y){
  if ((x-500) + 0.8*(y-500) > 1.25*150){
    return 1;
  }
  else if ((x-500)+(y-500)<-150){
    return 1;
  }
  else if ((x-500)-(y-500)<-150){
    return 1;
  }
  else if (0.9*(x-500)-(y-500)>(10/9)*20){
    return 1;
  }
  else {
    return 0;
  }
}

//Dumbbell hole
int dumbbell(int x, int y){
  if (pow(300,4)*pow((y-500),2) - pow((x-500),4)*(pow(300,2) - pow((x-500),2)) > pow(25,2)*pow(300,4)){
    return 1;
  }
  else {
    return 0;
  }
}

//Pointy square hole
int pointy(int x, int y){
  if (0.1*(pow((x-500),8)+pow((y-500),8)) + 4*(pow((y-500),2)*pow((x-500),6) + pow((y-500),6)*pow((x-500),2)) - 8*(pow((x-500),4)*pow((y-500),4)) > pow(125,8)){
    return 1;
  }
  else {
    return 0;
  }
}

int main(int argc, char* argv[]){

int rank, size, ierr;
int M = 1000;  // M length intervals
int N = 5000; // N time intervals
double platesize;
int ostart, start, end;
int colstart, colend;
int rowend, rowstart, rowende, rowstarte;
int missing, sum=0;
int ib, it;
int cont = 0;
int counter = 0;
double T;
double dt = 0.1/N;
double dx = 10./M;
double dtdx = dt/(dx*dx);
double Temp1 = 10, Temp2 = 0;
double epsilon = 0.01;
double diff, difftotal = 1.0;
double difft[size];
double points[size];
double sendD[M+1], sendU[M+1];
double recvA[M+1], recvB[M+1];
double tstart, tend, ttotal;
bool plate[M+1][M+1];
bool plate1d[(M+1)*(M+1)];
int uneven;

MPI_Status status;
MPI_Comm comm;
comm = MPI_COMM_WORLD;
MPI_Init(NULL,NULL);
MPI_Comm_rank(comm, &rank);
MPI_Comm_size(comm, &size);

//Create temperature matrix
double*** U = new double** [2];
for (int i=0; i<2; ++i){
  U[i] = new double*[M+1];
  for (int j=0; j<M+1; ++j){
    U[i][j] = new double[M+1];
  }
}

//Output values to check stability
cout<< "\ndx="<<dx<<", dt="<<dt<<", dt/dx²="<< dtdx<<endl;
if (rank == 0){
  tstart = MPI_Wtime();
}

//Define plate
for (int i=1; i<M; i++){
  for (int j=1; j<M; j++){
    plate[i][j] = heart(i,j);
    plate1d[((M+1)*i)+j] = heart(i,j);
    platesize = platesize + heart(i,j);
  }
}

for (int i=0; i<=M; i++){
  plate[i][0] = plate[i][M] = 0;
  plate1d[((M+1)*i)] = 0;
  plate1d[((M+1)*i)+M] = 0;
}

for (int j=1; j<M; j++){
  plate[0][j] = plate[M][j] = 0;
  plate1d[j] = 0;
  plate1d[((M+1)*M)+j] = 0;
}

//Points decomposition
if (rank == 0) {
  //calculate points for each processor
  for (int i=0; i<size-1; i++) {
    uneven = 1;
    start = 0;
    points[i] = ceil(platesize/size);
    //calculate processor starting points
    for (int j=0; j<i; j++) {
      start = start + points[j];
    }
    start = start + i;
    ostart = start;
    end = start + points[i];
    //repeat until no points are assigned within the hole
    while (uneven == 1) {
      missing = 0;
      for (int k=start; k<end; k++) {
        //calculate points assigned within hole
        missing = missing + (1-plate1d[k]);
      }
      //if no points have been assigned within hole then algorithm is done
      if (missing == 0) {
        uneven = 0;
      }
      else {
        //otherwise assign additional points to processor
        start = end;
        end = end + missing;
      }
    }
    //calculate final number of points assigned
    points[i] = end - ostart;
    sum = sum + points[i];
  }

  //assign remaining points to final processor
  points[size-1] = (M+1)*(M+1) - sum;
}

//broadcast to other processors
MPI_Bcast(points, size, MPI_DOUBLE, 0, comm);


//cout<<"Number of points for process number "<<rank<<" is "<<points[rank]<<endl;

//boundary conditions
  for (int i=0; i<=M; i++){
    U[0][i][0] = U[1][i][0] = Temp1;
    U[0][i][M] = U[1][i][M] = Temp1;
  }

  for (int j=1; j<M; j++){
    U[0][0][j] = U[1][0][j] = Temp1;
    U[0][M][j] = U[1][M][j] = Temp1;
  }

//initial guess
  for (int i=1; i<M; i++){
    for (int j=1; j<M; j++){
      if (plate[i][j] == 1){
        U[0][i][j] = (Temp1+Temp2)/2;
      }
      else {
        U[0][i][j] = Temp2;
      }
    }
  }

start = 0;
end = 0;

//each processor calculates start and end points
for(int i=0; i<=rank; i++){
  end = end + points[i];
}
start = end - points[rank];
//Column of final point
colend = end%(M+1);
if (colend == 0){
  colend = M;
}

//Column of starting point
colstart = start%(M+1);
if (colstart == 0){
  colstart = 1;
}

//calculate row of starting point and first full row (may be same)
if (start%(M+1) != 0){
  rowstarte = floor((float)start/(M+1));
  rowstart = rowstarte + 1;
}
else {
  rowstarte = start/(M+1);
  rowstart = rowstarte;
}

//calculate row of end point and last full row (may be same)
if (end%(M+1) != 0){
  rowende = floor((float)end/(M+1));
  rowend = rowende - 1;
}
else {
  rowende = end/(M+1);
  rowend = rowende;
}

//ensure final row isn't past end of matrix
if (rowend == M+1){
  rowend = M;
}
if (rowende == M+1){
  rowende = M;
}

//Until convergence
while(cont == 1){
//  if (diff > espilon/size){ //remove comment for individual convegence of processors
  diff = 0;
  T = T+dt;
  counter = counter + 1;
  ib = rowstarte;
  //calculate values of incomplete first row
  if (rowstarte != rowstart){
    for (int j=colstart; j<M; j++) {
      //if point is on the plate
      if (plate[ib][j] == 1){
        U[1][ib][j] = (dtdx)*(U[0][ib-1][j] + U[0][ib+1][j] + U[0][ib][j-1] + U[0][ib][j+1] - 4*U[0][ib][j]) + U[0][ib][j];
        //calculate absolute difference for convergence
        diff = diff + abs(U[1][ib][j] - U[0][ib][j]);
      }
      else {
        U[1][ib][j] = U[0][ib][j];
      }
    }
  }

  //calculate values of complete rows
  for (int i=rowstart; i<=rowend; i++) {
    for (int j=1; j<M; j++) {
      //if point is on the plate
      if (plate[i][j] == 1) {
        U[1][i][j] = (dtdx)*(U[0][i-1][j] + U[0][i+1][j] + U[0][i][j-1] + U[0][i][j+1] - 4*U[0][i][j] ) + U[0][i][j];
        //calculate absolute difference for convergence
        diff = diff + abs(U[1][i][j] - U[0][i][j]);
      }
      else {
        U[1][i][j] = U[0][i][j];
      }
    }
  }

  //calculate value of incomplete final row
  it = rowende;
  if (rowende != rowend){
    for (int j=1; j<colend; j++){
      //if point is on the plate
      if (plate[it][j] == 1){
        U[1][it][j] = (dtdx)*(U[0][it-1][j] + U[0][it+1][j] + U[0][it][j-1] + U[0][it][j+1] - 4*U[0][it][j]) + U[0][it][j];
        //calculate absolute difference for convergence
        diff = diff + abs(U[1][it][j] - U[0][it][j]);
      }
      else {
        U[1][it][j] = U[0][it][j];
      }
    }
  }

//  if ((counter%10)==1){ //For Halo Swapping every 10 iterations
  for (int j=0; j<colstart; j++){
    sendD[j] = U[1][ib+1][j];
  }

  for (int j=colstart; j<=M; j++){
    sendD[j] = U[1][ib][j];
  }

  for (int j=0; j<colend; j++){
    sendU[j] = U[1][it][j];
  }

  for (int j=colend; j<=M; j++){
    sendU[j] = U[1][it-1][j];
  }

  //Halo Swap between processors
  if (rank == 0){
    MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
    MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);

    for (int j=1; j<colend; j++){
      U[1][it+1][j] = recvA[j];
    }

    for (int j=colend; j<M; j++){
      U[1][it][j] = recvA[j];
    }

  }
  else if (rank == size-1){
    MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
    MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

    for (int j=1; j<colstart; j++){
      U[1][ib][j] = recvB[j];
    }

    for (int j=colstart; j<M; j++){
      U[1][ib-1][j] = recvB[j];
    }

  }
  else {
    MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
    MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

    for (int j=1; j<colstart; j++){
      U[1][ib][j] = recvB[j];
    }

    for (int j=colstart; j<M; j++){
      U[1][ib-1][j] = recvB[j];
    }

    MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
    MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);

    for (int j=1; j<colend; j++){
      U[1][it+1][j] = recvA[j];
    }

    for (int j=colend; j<M; j++){
      U[1][it][j] = recvA[j];
    }

//  } //For Halo Swapping every 10 iterations
  }

  //Update "old" values
  if (rowstart != rowstarte){
    for (int j=colstart; j<M; j++){
      U[0][ib-1][j] = U[1][ib-1][j];
    }
  }

  for (int i=rowstarte; i<=rowende; i++) {
    for (int j=1; j<M; j++) {
      U[0][i][j] = U[1][i][j];
    }
  }

  if (rowend != rowende){
    for (int j=1; j<colend; j++){
      U[0][it+1][j] = U[1][it+1][j];
    }
  }


//  if ((counter%10)==1){
  //Check convergence criteria
  MPI_Gather(&diff, 1, MPI_DOUBLE, difft, 1, MPI_DOUBLE, 0, comm);
  if (rank == 0){
    diff = 0;
    for (int i=0; i<size; i++){
      diff = diff + difft[i];
    }
    if (diff < epsilon){
      cont = 0;
    }
  }

  MPI_Bcast(&cont, 1, MPI_INT, 0, comm);
  }
//  } // For individual convergence remove comments
//  else {
//    T = T + dt;
//    if ((counter%10)==1){
//    if (rank == 0){
//      MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
//      MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, 
//    }
//    else if (rank == size-1){
//      MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
//      MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);
//    }
//    else {
//      MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
//      MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

//      MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
//      MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);
//    }
//    MPI_Gather(&diff, 1, MPI_DOUBLE, difft, 1, MPI_DOUBLE, 0, comm);
//    if (rank == 0){
//      difftotal = 0;
//      for (int i=0; i<size; i++){
//        difftotal = difftotal + difft[i];
//      }
      //cout<<"Diff Total = "<<difftotal<<endl;
//      if (difftotal < epsilon){
//        cont = 0;
//      }
      //cout<<"----"<<endl;
//    }
//    MPI_Bcast(&cont, 1, MPI_INT, 0 ,comm);
//    }
//}


//Time code
if (rank == 0){
  tend = MPI_Wtime();
  ttotal = tend - tstart;
  cout<<"Time = "<<ttotal<<endl;
}


for (int i=0; i<size; i++){
  MPI_Barrier(comm);
  if (rank == i){
    if (rowstart != rowstarte){
      for (int j=colstart; j<=M; j++){
        cout<<U[1][ib][j]<<" ";
      }
    cout<<" ~~~~~~~ "<<ib<<endl;
    }
    for(int k=rowstart; k<=rowend; k++){
      for(int j=0; j<=M; j++){
        cout<<U[1][k][j]<<" ";
      }
      cout<<" ------- "<<k<<endl;
    }
    if (rowend != rowende){
      cout<<"---"<<endl;
      for (int j=0; j<colend; j++){
        cout<<U[1][it][j]<<" ";
      }
      cout<<endl;
    }
  }
}


//Delete large temperature array
for (int i=0; i<2; i++){
  for (int j=0; j<M+1; j++){
    delete[] U[i][j];
  }
  delete[] U[i];
}
delete[] U;

0;

}
