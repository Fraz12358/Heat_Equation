#include <iostream>
#include <cmath>
#include <mpi.h>

using namespace std;

static const double PI = 3.1415926536; 

//Heart hole
int heart(int x, int y){
  if (2*pow((y-500),2) + pow((((7/4)*(x-500)) - 4*pow(abs(y-500),0.5)), 2) > pow(250,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Circle hole
int circle(int x, int y){
  if (pow((x-500),2) + pow((y-500),2) > pow(150,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Diamond hole
int diamond(int x, int y){
  if ((x-500) + 0.8*(y-500) > 1.25*150){
    return 1;
  }
  else if ((x-500)+(y-500)<-150){
    return 1;
  }
  else if ((x-500)-(y-500)<-150){
    return 1;
  }
  else if (0.9*(x-500)-(y-500)>(10/9)*20){
    return 1;
  }
  else {
    return 0;
  }
}

//Dumbbell hole
int dumbbell(int x, int y){
  if (pow(300,4)*pow((y-500),2) - pow((x-500),4)*(pow(300,2) - pow((x-500),2)) > pow(25,2)*pow(300,4)){
    return 1;
  }
  else {
    return 0;
  }
}

//Pointy square hole
int pointy(int x, int y){
  if (0.1*(pow((x-500),8)+pow((y-500),8)) + 4*(pow((y-500),2)*pow((x-500),6) + pow((y-500),6)*pow((x-500),2)) - 8*(pow((x-500),4)*pow((y-500),4)) > pow(125,8)){
    return 1;
  }
  else {
    return 0;
  }
}



int main(int argc, char* argv[]){

int rank, size, ierr;
int M = 1000;  // M length intervals
int N = 5000; // N time intervals
double platesize;
int ostart, start, end;
int rowstart, rowend;
double missing, sum=0;
double assigned;
int cont = 1;
int counter = 0;
double T;
double dt = 0.1/N;
double dx = 10./M;
double dtdx = dt/(dx*dx);
double Temp1 = 10, Temp2 = 0;
double epsilon = 0.01;
double diff=1.0, conv=1.0;
double difftotal=1.0;
double difft[size];
double points[size];
double sendD[M+1], sendU[M+1];
double recvA[M+1], recvB[M+1];
double tstart, tend, ttotal;
bool plate[M+1][M+1];
bool plate1d[(M+1)*(M+1)];
int uneven;

MPI_Status status;
MPI_Comm comm;
comm = MPI_COMM_WORLD;
MPI_Init(NULL,NULL);
MPI_Comm_rank(comm, &rank);
MPI_Comm_size(comm, &size);



//Create temperature matrix
double*** U = new double** [2];
for (int i=0; i<2; ++i){
  U[i] = new double*[M+1];
  for (int j=0; j<M+1; ++j){
    U[i][j] = new double[M+1];
  }
}

//Begin timing
if (rank == 0){
  tstart = MPI_Wtime();
}

//Output values for stability
if (rank == 0){
  cout<< "\ndx="<<dx<<", dt="<<dt<<", dt/dx²="<< dtdx<<endl;
}

//Define plate
for (int i=1; i<M; i++){
  for (int j=1; j<M; j++){
    plate[i][j] = heart(i,j);
    plate1d[((M+1)*i)+j] = heart(i,j);
    platesize = platesize + heart(i,j);
  }
}

for (int i=0; i<=M; i++){
  plate[i][0] = plate[i][M] = 0;
  plate1d[((M+1)*i)] = 0;
  plate1d[((M+1)*i)+M] = 0;
}

for (int j=1; j<M; j++){
  plate[0][j] = plate[M][j] = 0;
  plate1d[j] = 0;
  plate1d[((M+1)*M)+j] = 0;
}

//Rows decomposition
if (rank == 0){
  //calculate rows for each processor
  for (int i=0; i<size-1; i++) {
    uneven = 1;
    assigned = 0;
    start = 0;
    points[i] =round((platesize/size)/(M+1))*(M+1);
    //Calculate starting point
    for (int j=0; j<i; j++) {
      start = start + points[j];
    }
    start = start + i;
    ostart = start;
    end = start + points[i];
    //Until enough rows have been added
    while (uneven == 1) {
      missing = 0;
      //Assign rows, count how many are within the hole
      //and how many have been assigned
      for (int k=start; k<end; k++) {
        missing = missing + (1-plate1d[k]);
        assigned = assigned + plate1d[k];
      }
      //If rows to be assigned is 0
      if (round(missing/(M+1)) == 0) {
        uneven = 0;
      }
      //If assigned enough points already
      else if (assigned > ceil(platesize/size)) {
        uneven = 0;
      }
      //Otherwise continue to assign rows
      else {
        start = end;
        end = end + round(missing/(M+1))*(M+1);
      }
    }
    //Calculate number of points assigned to processor
    points[i] = end - ostart;
    sum = sum + points[i];
  }

  //Assign remaining rows to final processor
  points[size-1] = (M+1)*(M+1) - sum;
}

//Broadcast row assignment to all processors
MPI_Bcast(points, size, MPI_DOUBLE, 0, comm);


//Boundary conditions
for (int i=0; i<=M; i++){
  U[0][i][0] = U[1][i][0] = Temp1;
  U[0][i][M] = U[1][i][M] = Temp1;
}

for (int j=1; j<M; j++){
  U[0][0][j] = U[1][0][j] = Temp1;
  U[0][M][j] = U[1][M][j] = Temp1;
}

//Initial guesses
for (int i=1; i<M; i++){
  for (int j=1; j<M; j++){
    if (plate[i][j] == 1){
      U[0][i][j] = (Temp1+Temp2)/2;
    }
    else {
      U[0][i][j] = Temp2;
    }
  }
}

start = 0;
end = 0;

//calculate start and end point for processor
for (int i=0; i<rank; i++){
  start = start + points[i];
}
end = start + points[rank];

//calculate start and end row for processor
rowstart = start/(M+1);
rowend = end/(M+1) - 1;

//ensure final row is within matrix bounds
if (rowend > M){
  rowend = M;
}


while (cont == 1){
//  counter = counter+1; // variable for communication every 10 iterations
//  if (diff>epsilon/size){ //remove comments for individual convergence
  diff = 0;
  T = T+dt;

  //update temperature values
  for (int i=rowstart; i<=rowend; i++){
    for (int j=1; j<M; j++){
      //if on the plate update values
      if (plate[i][j] == 1){
        U[1][i][j] = (dtdx)*(U[0][i-1][j] + U[0][i+1][j] + U[0][i][j-1] + U[0][i][j+1] - 4*U[0][i][j]) + U[0][i][j];
        diff = diff + abs(U[1][i][j] - U[0][i][j]);
      }
      //if not on the plate then don't
      else {
        U[1][i][j] = U[0][i][j];
      }
    }
  }

//  if ((counter%10)==1){ //remove comment for periodic communication
  for(int j=0; j<=M; j++){
    sendD[j] = U[1][rowstart][j];
  }

  for(int j=0; j<=M; j++){
    sendU[j] = U[1][rowend][j];
  }

  //communication between processors
  if (rank == 0) {
    MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
    MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);

    for(int j=0; j<=M; j++){
      U[1][rowend+1][j] = recvA[j];
    }
  }
  else if (rank == size-1) {
    MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
    MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

    for(int j=0; j<=M; j++){
      U[1][rowstart-1][j] = recvB[j];
    }
  }
  else {
    MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
    MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

    for(int j=0; j<=M; j++){
      U[1][rowstart-1][j] = recvB[j];
    }

    MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
    MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);

    for(int j=0; j<=M; j++){
      U[1][rowend+1][j] = recvA[j];
    }
//  } //remove comment for periodic communication
  }

  //update old values
  if (rank != 0){
    for (int j=1; j<M; j++){
      U[0][rowstart-1][j] = U[1][rowstart-1][j];
    }
  }

  for (int i=rowstart; i<=rowend; i++){
    for (int j=1; j<M; j++){
      U[0][i][j] = U[1][i][j];
    }
  }

  if (rank != size-1){
    for (int j=1; j<M; j++){
      U[0][rowend+1][j] = U[1][rowend+1][j];
    }
  }

//  if ((counter%10)==1){  //remove comment for periodic communication
  MPI_Gather(&diff, 1, MPI_DOUBLE, difft, 1, MPI_DOUBLE, 0, comm);
  if (rank == 0){
    difftotal = 0;
    for (int i=0; i<size; i++){
      difftotal = difftotal + difft[i];
    }
    if (difftotal < epsilon){
      cont = 0;
    }
  }

  MPI_Bcast(&cont, 1, MPI_INT, 0, comm);

//remove comments for individual convergence
//  }


//  }
//  else {
//    T = T+dt;
//    if ((counter%10)==1){
//    if (rank == 0){
//      MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
//      MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);
//    }
//    else if (rank == size-1){
//      MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
//      MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);
//    }
//    else {
//      MPI_Send(sendD, M+1, MPI_DOUBLE, (rank-1), 1, comm);
//      MPI_Recv(recvB, M+1, MPI_DOUBLE, (rank-1), 0, comm, &status);

//      MPI_Send(sendU, M+1, MPI_DOUBLE, (rank+1), 0, comm);
//      MPI_Recv(recvA, M+1, MPI_DOUBLE, (rank+1), 1, comm, &status);
//    }
//    MPI_Gather(&diff, 1, MPI_DOUBLE, difft, 1, MPI_DOUBLE, 0, comm);
//    if (rank == 0){
//      difftotal = 0;
//      for (int i=0; i<size; i++){
//        difftotal = difftotal + difft[i];
//      }
//      if (difftotal < epsilon){
//        cont = 0;
//      }
//    }
//    MPI_Bcast(&cont, 1, MPI_INT, 0, comm);
//    }
//  }


}

//End timing of code
if (rank == 0){
  tend = MPI_Wtime();
  ttotal = tend - tstart;
  cout<<"Time = "<<ttotal<<endl;
}

for (int i=0; i<size; i++){
  MPI_Barrier(comm);
  if (rank == i){
    for (int i=rowstart; i<=rowend; i++){
      for (int j=0; j<=M; j++){
        cout<<U[1][i][j]<<" ";
      }
    cout<<"----"<<i<<endl;
    }
  }
}

//Delete large temperature matrix
for (int i=0; i<2; i++){
  for (int j=0; j<M+1; j++){
    delete[] U[i][j];
  }
  delete[] U[i];
}

delete[] U;

0;


}
