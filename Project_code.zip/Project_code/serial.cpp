#include <chrono>
#include <iostream>
#include <cmath>

using namespace std;

static const double PI = 3.1415926536; 

//function for heart hole
int heart(int x, int y){
  if (2*pow((y-500),2) + pow((((7/4)*(x-500)) - 4*pow(abs(y-500),0.5)), 2) > pow(250,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Circle hole
int circle(int x, int y){
  if (pow((x-500),2) + pow((y-500),2) > pow(150,2)){
    return 1;
  }
  else {
    return 0;
  }
}

//Diamond hole
int diamond(int x, int y){
  if ((x-500) + 0.8*(y-500) > 1.25*150){
    return 1;
  }
  else if ((x-500)+(y-500)<-150){
    return 1;
  }
  else if ((x-500)-(y-500)<-150){
    return 1;
  }
  else if (0.9*(x-500)-(y-500)>(10/9)*20){
    return 1;
  }
  else {
    return 0;
  }
}

//Dumbbell hole
int dumbbell(int x, int y){
  if (pow(300,4)*pow((y-500),2) - pow((x-500),4)*(pow(300,2) - pow((x-500),2)) > pow(25,2)*pow(300,4)){
    return 1;
  }
  else {
    return 0;
  }
}

//Pointy square hole
int pointy(int x, int y){
  if (0.1*(pow((x-500),8)+pow((y-500),8)) + 4*(pow((y-500),2)*pow((x-500),6) + pow((y-500),6)*pow((x-500),2)) - 8*(pow((x-500),4)*pow((y-500),4)) > pow(125,8)){
    return 1;
  }
  else {
    return 0;
  }
}

int main(int argc, char* argv[]){

int M = 1000;  // M length intervals
int N = 5000; // N time intervals
double T;
double dt = 0.1/N;
double dx = 10./M;
double dtdx = dt/(dx*dx);
double Temp1 = 10, Temp2 = 0; //Boundary conditions
double epsilon = 0.01; //Convergence criteria
double diff, conv=1.0;
double sum=0;
bool plate[M+1][M+1];

//Create matrix for storing temperature values
double*** U = new double** [2];
for (int i=0; i<2; ++i){
  U[i] = new double*[M+1];
  for (int j=0; j<M+1; ++j){
    U[i][j] = new double[M+1];
  }
}


//Check for stability of method
cout<< "\ndx="<<dx<<", dt="<<dt<<", dt/dx²="<< dtdx<<endl;

//Define Boolean matrix to define whether points are on the plate or not
for (int i=0; i<M; i++){
  for (int j=0; j<M; j++){
    //replace heart with desired hole shape
    plate[i][j] = heart(i,j);
    sum = sum + heart(i,j);
  }
}

//Output to calculate how much of plate is covered by hole
cout<<"SUM = "<<sum<<endl;

//Begin timing code
auto start = chrono::high_resolution_clock::now();


//Set boundary conditions
for(int i=0; i<=M; i++){
  U[0][i][0] = Temp1;
  U[0][i][M] = Temp1;
  U[1][i][0] = Temp1;
  U[1][i][M] = Temp1;
}

for(int j=1; j<M; j++){
  U[0][0][j] = Temp1;
  U[0][M][j] = Temp1;
  U[1][0][j] = Temp1;
  U[1][M][j] = Temp1;
}

//Set initial conditions
for (int i=1; i<M; i++){
  for (int j=1; j<M; j++){
    if (plate[i][j] == 1){
      U[0][i][j] = (Temp1+Temp2)/2;
    }
    else{
      U[0][i][j] = (Temp2);
    }
  }
}


// use numerical scheme to obtain the future values of temperature on the M+1 space points
//until convergence criteria is met
while (conv > epsilon) {
  diff = 0;
  T = T + dt;
  //Update values if on plate
  for (int i=1; i<M; ++i){
    for (int j=1; j<M; ++j){
      if (plate[i][j] == 1){
        U[1][i][j] = (dtdx)*( U[0][i-1][j] + U[0][i+1][j] + U[0][i][j-1] + U[0][i][j+1] - 4*U[0][i][j] ) + U[0][i][j];
        //Calculate absolute difference
        diff = diff + U[1][i][j] - U[0][i][j];
      }
      else{
        U[1][i][j] = U[0][i][j];
      }
    }
  }

// update "old" values
  for (int i=1; i<M; ++i){
    for (int j=1; j<M; ++j){
      U[0][i][j] = U[1][i][j];
    }
  }
  conv = diff;
}

//Time spent running code
auto finish = chrono::high_resolution_clock::now();
chrono::duration<double> elapsed = finish - start;
cout<<"Elapsed time = "<<elapsed.count()<<"s\n"<<endl;


// print out matrix entries of numerical solution
cout << "\nNumerical values at M="<<M<<" space points at time T="<<T<<":"<<endl;
cout << "\nNumerical solutions\n"<<endl;
for(int i=0; i<=M; ++i){
  for (int j=0; j<=M; ++j){
    cout<<U[0][i][j]<<" ";
  }
  cout<<endl;
}

//delete large array
for (int i=0; i<2; i++){
  for (int j=0; j<M+1; j++){
    delete[] U[i][j];
  }
  delete[] U[i];
}
delete[] U;


return 0;

}
